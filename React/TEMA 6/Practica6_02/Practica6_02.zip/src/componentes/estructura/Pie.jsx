import React from "react";
import "./Pie.css";

const Pie = () => {
  return (
    <>
      <footer id='pie'>
        Este material ha sido desarrollado para el módulo de Desarrollo Web en
        Entorno Cliente.
      </footer>
    </>
  );
};

export default Pie;
