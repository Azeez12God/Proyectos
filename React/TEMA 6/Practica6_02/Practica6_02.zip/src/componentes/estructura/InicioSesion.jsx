import React from "react";

const InicioSesion = () => {
  return (
    <>
      <div>
        <button onClick={() => {}}>Cerrar sesión</button>
      </div>
    </>
  );
};

export default InicioSesion;
